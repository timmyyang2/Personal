package arrayProject; //package name

public class ArrayDriver { //class

	public static void main(String[] args) { //main method
		Array array = new Array(); //new Array object
		array.setData(2, "sahil"); //calls setData method
		array.getData(4); //calls getData
		array.getSize(); //calls getSize
		array.getArray(); //calls getArray
		array.eraseArray(); //calls eraseArray
	}

}
